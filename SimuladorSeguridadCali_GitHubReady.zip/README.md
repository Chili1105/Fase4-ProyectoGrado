# 🛡️ Simulador de Seguridad Urbana – Cali

Simulador interactivo que combina alertas ciudadanas, sensores IoT y predicción de riesgo por zonas.

## 🚀 Requisitos

- Python 3.8 o superior
- Git (opcional para clonar el proyecto)

## 💻 Instrucciones de instalación local

### 1. Clona este repositorio o descarga el ZIP

```bash
git clone https://github.com/tu-usuario/simulador-seguridad-cali.git
cd simulador-seguridad-cali
```

O simplemente descarga y descomprime el archivo ZIP.

### 2. Crea un entorno virtual

```bash
python3 -m venv venv
source venv/bin/activate      # En Linux/Mac
venv\Scripts\activate.bat   # En Windows
```

### 3. Instala dependencias

```bash
pip install -r requirements.txt
```

### 4. Ejecuta la aplicación

```bash
python app.py
```

### 5. Abre tu navegador en:

```
http://127.0.0.1:5050
```

## 🧠 Características

- Módulo predictivo por barrio, día y hora.
- Reporte manual de alertas desde ciudadanos o sensores.
- Visualización en mapa con íconos diferenciados.
- Generador automático de alertas de prueba.
- Totalmente ejecutable en local.

---

¡Desarrollado con ❤️ para proyectos urbanos inteligentes!

from flask import render_template, request, jsonify
from app import app
import random
from datetime import datetime

alerts = []
barrios = ['Aguablanca', 'Centro', 'San Fernando', 'La Flora', 'El Lido', 'Siloé', 'Santa Mónica', 'Ciudad Córdoba', 'Alfonso López', 'San Judas', 'El Guabal', 'Pasoancho', 'Calipso', 'Meléndez', 'Granada', 'El Ingenio']
dias_esp = {
    "Monday": "Lunes", "Tuesday": "Martes", "Wednesday": "Miércoles",
    "Thursday": "Jueves", "Friday": "Viernes", "Saturday": "Sábado", "Sunday": "Domingo"
}

@app.route("/")
def index():
    return render_template("index.html", barrios=barrios)

@app.route("/api/alerts")
def api_alerts():
    return jsonify(alerts)

@app.route("/api/predict", methods=["POST"])
def api_predict():
    data = request.json
    barrio = data["barrio"]
    dia = data["dia"]
    hora = data["hora"]
    coincidencias = [a for a in alerts if a["barrio"] == barrio and a["dia"] == dia and a["hora_12"] == hora]
    riesgo = "ALTO" if len(coincidencias) > 2 else "BAJO"
    return jsonify({"riesgo": riesgo})

@app.route("/api/add_alert", methods=["POST"])
def add_alert():
    data = request.json
    descripcion = f"{data['origen']}: {data['descripcion']}"
    alerts.append({
        "id": len(alerts) + 1,
        "barrio": data["barrio"],
        "lat": 3.42 + random.random() * 0.08,
        "lng": -76.55 + random.random() * 0.08,
        "hora_12": data["hora"],
        "dia": data["dia"],
        "descripcion": descripcion
    })
    return jsonify({"status": "ok"})

def generar_alerta_automatica(barrio, origen, descripcion, dia=None, hora=None):
    now = datetime.now()
    hora_12 = hora if hora else now.strftime("%I:%M %p")
    dia_esp = dia if dia else dias_esp[now.strftime("%A")]
    alerts.append({
        "id": len(alerts) + 1,
        "barrio": barrio,
        "lat": 3.42 + random.random() * 0.08,
        "lng": -76.55 + random.random() * 0.08,
        "hora_12": hora_12,
        "dia": dia_esp,
        "descripcion": f"{origen}: {descripcion}"
    })

# Combinaciones que deben generar NO SEGURO
combinaciones_no_seguras = [
    ("San Fernando", "Lunes", "03:00 PM"),
    ("Aguablanca", "Viernes", "08:00 PM"),
    ("Centro", "Sábado", "11:00 AM")
]
for barrio, dia, hora in combinaciones_no_seguras:
    for _ in range(3):
        generar_alerta_automatica(barrio, "Sensor inteligente", "Precarga crítica", dia, hora)

# Alertas aleatorias distribuidas por todos los barrios y orígenes
for _ in range(32):
    generar_alerta_automatica(
        random.choice(barrios),
        random.choice(['Ciudadano desde App', 'Cámara inteligente', 'Sensor de movimiento', 'Botón de pánico']),
        random.choice(['Robo en proceso', 'Persona sospechosa', 'Ruido inusual', 'Emergencia médica', 'Disparo detectado', 'Movimiento en zona restringida', 'Alerta de fuego', 'Objeto abandonado', 'Actividad no autorizada'])
    )
